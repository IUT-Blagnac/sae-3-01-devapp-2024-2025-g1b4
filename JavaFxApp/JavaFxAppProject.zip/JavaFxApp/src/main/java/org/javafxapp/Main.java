package org.javafxapp;

import org.javafxapp.controller.MainMenu;

import java.util.ArrayList;
import java.util.List;


public class Main {


    public static final String appDataPath="./appData.json";

    public static void main(String[] args) {
        MainMenu.main2(args);
    }
}
